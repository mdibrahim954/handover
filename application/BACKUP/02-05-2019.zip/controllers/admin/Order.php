<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Order extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('user_id') && $this->session->userdata('user_type_id') != 1) {
            redirect(base_url());
        }
//        $this->load->model('user_model');
    }

    public function test() {
        echo 'This is testing Module';
    }

    public function index() {
        $data = array();
        $data['menu'] = '';
        $user_id = $this->session->userdata('user_id');

        $data['delivery'] = $this->db
                ->select('*')
                ->get('order_type')
                ->result();
        $data['area'] = $this->db
                ->select('*')
                ->order_by('area_name', 'asc')
                ->get('areas')
                ->result();
        //get serller/merchant-----------------------
        $data['sellerInfo'] = $this->db
                ->select('*')
                ->where('isactive', 1)
                ->get('users')
                ->result();

        $data['header'] = $this->load->view('dashboard-admin/common/admin-header', $data, TRUE);
        $data['footer'] = $this->load->view('dashboard-admin/common/admin-footer', $data, TRUE);
        $this->load->view('dashboard-admin/order/new-order', $data);
    }

    public function order_track() {

        $tracknumber = trim($this->input->post('tracknumber'));
        if (!isset($tracknumber)) {
            redirect('admin/dashboard');
        }
        $data['result'] = $this->db
                ->select('*')
                ->where('track_number', $tracknumber)
                ->get('orders')
                ->row();
//           echo '<pre>';
//           print_r($data['result']);
//           echo '</pre>';

        $data['orderComments'] = $this->db
                ->select('*')
                ->where('order_id', $data['result']->order_id)
                ->get('order_comments')
                ->result();

        $data['header'] = $this->load->view('dashboard-admin/common/admin-header', $data, TRUE);
        $data['footer'] = $this->load->view('dashboard-admin/common/admin-footer', $data, TRUE);
        $this->load->view('dashboard-admin/home-order-track', $data);
    }

    public function order_comments() {
        $order_id = $this->input->post('order_id');
        if (!isset($order_id)) {
            redirect('admin/dashboard');
        }
        $fullname = trim($this->input->post('fullname'));
        $comment = trim($this->input->post('comment'));

        $input = array(
            'order_id' => $order_id,
            'Fullname' => $fullname,
            'Comment' => $comment,
        );

        $response = $this->db->insert('order_comments', $input);

        $data['orderComments'] = $this->db
                ->select('*')
                ->where('order_id', $order_id)
                ->get('order_comments')
                ->result();

        if ($response == 1) {
            $sess['success'] = 'Success!';
            $this->session->set_userdata($sess);


            $data['result'] = $this->db
                    ->select('*')
                    ->where('order_id', $order_id)
                    ->get('orders')
                    ->row();

            $data['header'] = $this->load->view('dashboard-admin/common/admin-header', $data, TRUE);
            $data['footer'] = $this->load->view('dashboard-admin/common/admin-footer', $data, TRUE);
            $this->load->view('dashboard-admin/home-order-track', $data);
        }
    }

    public function seller_info() {
        $seller_id = $this->input->post('sellerid');
        $sellerInfo = $this->db
                ->select('*')
                ->where('userid', $seller_id)
                ->get('users')
                ->row();

        $data_act = array('mobile' => $sellerInfo->mobile, 'address' => $sellerInfo->address);
        echo json_encode($data_act);
    }

    public function order_save() {

        /*
        $item = $this->input->post('item'); //array
        foreach($item as $item2){
            echo '<pre>';
            print_r($item2);
            echo '</pre>';            
        }
        echo '<pre>';
        print_r($_POST);
        echo '</pre>';
        exit();
         */

        $item = $this->input->post('item'); //array

        $sellerID = trim($this->input->post('sellerid'));
        $sellerInfo = $this->db
                ->select('*')
                ->where('userid', $sellerID)
                ->get('users')
                ->row();

        $sellersname = $sellerInfo->first_name . ' ' . $sellerInfo->last_name;

        $deliverytypeid = $this->input->post('deliverytypeid');
        $sellersmobile = trim($this->input->post('sellersmobile'));
        $sellersaddress = trim($this->input->post('sellersaddress'));
        $pickupareaid = $this->input->post('pickupareaid');
        $pickupDate = $this->input->post('pickupDate');
        $pickupDate = date('Y-m-d', strtotime($pickupDate));
        $pickupTime = $this->input->post('pickupTime');
        $pickupTime = date("H:i:s", strtotime($pickupTime)); //convert 12 hr to 24 hours

        $customername = trim($this->input->post('customername'));
        $customermobile = trim($this->input->post('customermobile'));
        $customeraddress = trim($this->input->post('customeraddress'));
        $deliveryareaid = $this->input->post('deliveryareaid');
        $deliveryDate = $this->input->post('deliveryDate');
        $deliveryDate = date('Y-m-d', strtotime($deliveryDate));
        $deliveryTime = $this->input->post('deliveryTime');
        $deliveryTime = date("H:i:s", strtotime($deliveryTime)); //convert 12 hr to 24 hours

        $referenceinvoice = trim($this->input->post('referenceinvoice'));
        $packagedescription = trim($this->input->post('packagedescription'));
        $deliverynote = trim($this->input->post('deliverynote'));

        $itemname_delivery = trim($this->input->post('itemname_delivery'));
        $quantity_delivery = $this->input->post('quantity_delivery');
        $unitprice_delivery = $this->input->post('unitprice_delivery');

        if ($quantity_delivery == '') {
            $unitprice_delivery = '';
        }

        $itemname = $this->input->post('itemname'); //array
        $quantity = $this->input->post('quantity'); //array
        $unitprice = $this->input->post('unitprice'); //array

        $final_array = array_map(NULL, $itemname, $quantity, $unitprice);

        //order Track Number---------------------------------------------------------------------------
        $areaInfo = $this->db
                ->select('*')
                ->where('areaid', $deliveryareaid)
                ->get('areas')
                ->row();

        $OrderID = $this->db->select("*")->limit(1)->order_by('order_id', "DESC")->get("orders")->row();
        $lastOrderID = $OrderID->order_id;
        $lastOrderID = $lastOrderID + 1;
        $track_number = strtoupper(substr($areaInfo->area_name, 0, 2)) . sprintf("%06d", $lastOrderID);

        $user_id = $this->session->userdata('user_id');

        $newOrder_Default = $this->db
                ->select('orderstateid')
                ->where('neworder_default', 1)
                ->get('order_state')
                ->row();

        $startTime = date("Y-m-d H:i:s");
        $cenvertedCurrentTime = date('Y-m-d H:i:s', strtotime('+6 hour', strtotime($startTime)));

        $input = array(
            'track_number' => $track_number,
            'delivery_charge' => '0',
            'order_type_id' => $deliverytypeid,
            'seller_name' => $sellersname,
            'seller_mobile' => $sellersmobile,
            'seller_address' => $sellersaddress,
            'pickup_area_id' => $pickupareaid,
            'pickup_time' => $pickupDate . ' ' . $pickupTime,
            'customer_name' => $customername,
            'customer_mobile' => $customermobile,
            'customer_address' => $customeraddress,
            'delivery_area_id' => $deliveryareaid,
            'delivery_time' => $deliveryDate . ' ' . $deliveryTime,
            'reference_invoice' => $referenceinvoice,
            'package_description' => $packagedescription,
            'deliveryman_note' => $deliverynote,
            'is_client_order' => 1,
            'order_state_id' => $newOrder_Default->orderstateid,
            'user_id' => $sellerID,
            'order_created_by' => $user_id,
            'created_at' => $cenvertedCurrentTime,
            'updated_at' => $cenvertedCurrentTime,
        );

        $response = $this->db->insert('orders', $input);
        $last_insert_id = $this->db->insert_id();

//        echo '<pre>';
//            print_r($newOrder_Default);
//        print_r($input);
//        print_r($final_array);
//        print_r($_POST);
//        echo '</pre>';
//exit();       
        //insert item delivery charge---------------------------------------------------------
        $orderItemCharge = array(
            'order_id' => $last_insert_id,
            'item_name' => $itemname_delivery,
            'quantity' => $quantity_delivery,
            'unit_price' => $unitprice_delivery,
            'total' => $quantity_delivery * $unitprice_delivery,
            'created_at' => $cenvertedCurrentTime,
            'updated_at' => $cenvertedCurrentTime,
        );
        $response2 = $this->db->insert('order_details', $orderItemCharge);

        //insert item price---------------------------------------------------------
        if (!empty($item)) {
            foreach ($item as $item2) {
                if (($item2['quantity'] != '' || $item2['quantity'] != 0) && ($item2['price'] != '' || $item2['price'] != 0)) {
                    $item_code=$item2['item_code'];
                    $orderItem = array(
                        'order_id' => $last_insert_id,
                        'item_name' => $item2['itemname'],
                        'item_code' => $item_code,
                        'quantity' => $item2['quantity'],
                        'unit_price' => $item2['price'],
                        'total' => $item2['quantity'] * $item2['price'],
                        'created_at' => $cenvertedCurrentTime,
                        'updated_at' => $cenvertedCurrentTime,
                    );
                    $response3 = $this->db->insert('order_details', $orderItem);
                    
                    if ($item_code != '') {

                        $productInfo = $this->db
                                ->where('item_code', $item_code)
                                ->get('product')
                                ->row();

                        if (!empty($productInfo)) {
                            
                            $itemQtyOld=$productInfo->qty;
                            $remItemQty=$itemQtyOld-$item2['quantity'];

                            //update Product Qty by  item_code to product inventory-----------------------------------------
                            $responseInventory = $this->db
                                    ->where('item_code', $item_code)
                                    ->set('qty', $remItemQty)
                                    ->update('product');

                            //insert to product log----------------------------------------------------------------------
                            $inventoryLog = array(
                                'product_id' => 0,
                                'order_id' => $last_insert_id,
                                'category_id' => 0,
                                'name' => $item2['itemname'],
                                'item_code' => $item_code,
                                'qty' => $item2['quantity'],
                                'type' => 'New Order Create',
                                'created_at' => $cenvertedCurrentTime,
                                'updated_at' => $cenvertedCurrentTime,
                            );
                            $responseInventoryLog = $this->db->insert('product_logs', $inventoryLog);
                        }
                    }
                }
            }
        }

        $sess['success'] = 'Created Successfully!';
        $this->session->set_userdata($sess);
        redirect('admin/order');
    }

    public function deleteOrderItem() {
        $order_details_id = $this->input->post('order_details_id');

        if (isset($order_details_id)) {
            //adjust product inventory-------------------------------------------
            $productDetails = $this->db->select('*')->where('order_details_id', $order_details_id)->get('order_details')->row();
            if (!empty($productDetails)) {
                $item_code = $productDetails->item_code;
                $order_id = $productDetails->order_id;
                if ($item_code != '') {

                    $prodLogs = $this->db
                            ->select('*')
                            ->where('order_id', $order_id)
                            ->where('item_code', $item_code)
                            ->where('status', 1)
                            ->get('product_logs')
                            ->row();
                    if (!empty($prodLogs)) {
                            $pQty = $prodLogs->qty;
                            $itemCode_get = $prodLogs->item_code;
                            $itemInfoGet = $this->db->where('item_code', $itemCode_get)->get('product')->row();
                            if (!empty($itemInfoGet)) {
                                $itemOldQty = $itemInfoGet->qty;
                                $totalItemQty = $pQty + $itemOldQty;
                                //update item qty---------------------------
                                $this->db
                                        ->where('item_code', $itemCode_get)
                                        ->set('qty', $totalItemQty)
                                        ->update('product');
                                $this->db
                                        ->where('order_id', $order_id)
                                        ->where('item_code', $itemCode_get)
                                        ->set('status', 0)
                                        ->update('product_logs');
                            }
                    }
                }
            }
        }

        $response = $this->db
                ->where('order_details_id', $order_details_id)
                ->delete('order_details');

        if ($response == 1) {
            echo 'Success';
        }
    }

    public function order_update() {

        $item = $this->input->post('item'); //array
//        echo '<pre>';
//        print_r($_POST);
//        echo '</pre>';
//        exit();
        $order_id = $this->input->post('order_id');

        $order_type_id = $this->input->post('order_type_id');
        $sellersname = trim($this->input->post('seller_name'));
        $sellersmobile = trim($this->input->post('sellersmobile'));
        $sellersaddress = trim($this->input->post('sellersaddress'));
        $pickupareaid = $this->input->post('pickupareaid');
        $pickupDate = $this->input->post('pickupDate');
        $pickupDate = date('Y-m-d', strtotime($pickupDate));
        $pickupTime = $this->input->post('pickupTime');
        $pickupTime = date("H:i:s", strtotime($pickupTime)); //convert 12 hr to 24 hours

        $customername = trim($this->input->post('customername'));
        $customermobile = trim($this->input->post('customermobile'));
        $customeraddress = trim($this->input->post('customeraddress'));
        $deliveryareaid = $this->input->post('deliveryareaid');
        $deliveryDate = $this->input->post('deliveryDate');
        $deliveryDate = date('Y-m-d', strtotime($deliveryDate));
        $deliveryTime = $this->input->post('deliveryTime');
        $deliveryTime = date("H:i:s", strtotime($deliveryTime)); //convert 12 hr to 24 hours

        $referenceinvoice = trim($this->input->post('referenceinvoice'));
        $packagedescription = trim($this->input->post('packagedescription'));
        $deliverynote = trim($this->input->post('deliverynote'));

//        $itemname_delivery = trim($this->input->post('itemname_delivery'));
//        $quantity_delivery = $this->input->post('quantity_delivery');
//        $unitprice_delivery = $this->input->post('unitprice_delivery');
//
//        if ($quantity_delivery == '') {
//            $unitprice_delivery = '';
//        }


        /*
          //for new item-------------------------------------------------------------
          $itemname = array();
          $quantity = array();
          $unitprice = array();
          $final_array = array();

          $itemname = $this->input->post('itemname'); //array
          $quantity = $this->input->post('quantity'); //array
          $unitprice = $this->input->post('unitprice'); //array

          if (!empty($itemname) && !empty($quantity) && !empty($unitprice)) {
          $final_array = array_map(NULL, $itemname, $quantity, $unitprice);
          }

          //for old item information update---------------------------------------------------
          $itemname2 = array();
          $quantity2 = array();
          $unitprice2 = array();
          $final_array2 = array();

          $itemname2 = $this->input->post('itemname2'); //array
          $quantity2 = $this->input->post('quantity2'); //array
          $unitprice2 = $this->input->post('unitprice2'); //array
          $oder_details_id2 = $this->input->post('oder_details_id2'); //array

          if (!empty($itemname2) && !empty($quantity2) && !empty($unitprice2)) {
          $final_array2 = array_map(NULL, $itemname2, $quantity2, $unitprice2, $oder_details_id2);
          }
          foreach ($final_array2 as $item2) {

          $orderItem2 = array(
          'item_name' => $item2[0],
          'quantity' => $item2[1],
          'unit_price' => $item2[2],
          'total' => $item2[1]*$item2[2],
          'updated_at' => date('Y-m-d H:i:s'),
          );


          $responseUpdateItem = $this->db
          ->where('order_details_id', $item2[3])
          ->update('order_details', $orderItem2);
          echo '<br>';
          }
         */


        //order Track Number---------------------------------------------------------------------------
        $areaInfo = $this->db
                ->select('*')
                ->where('areaid', $deliveryareaid)
                ->get('areas')
                ->row();

        $OrderID = $this->db->select("*")->limit(1)->order_by('order_id', "DESC")->get("orders")->row();
        $lastOrderID = $OrderID->order_id;
        $track_number = strtoupper(substr($areaInfo->area_name, 0, 2)) . sprintf("%06d", $lastOrderID);

        $user_id = $this->session->userdata('user_id');

        $newOrder_Default = $this->db
                ->select('orderstateid')
                ->where('neworder_default', 1)
                ->get('order_state')
                ->row();


        $startTime = date("Y-m-d H:i:s");
        $cenvertedCurrentTime = date('Y-m-d H:i:s', strtotime('+6 hour', strtotime($startTime)));
        $update_order = array(
            'delivery_charge' => '0',
            'order_type_id' => $order_type_id,
            'seller_name' => $sellersname,
            'seller_mobile' => $sellersmobile,
            'seller_address' => $sellersaddress,
            'pickup_area_id' => $pickupareaid,
            'pickup_time' => $pickupDate . ' ' . $pickupTime,
            'customer_name' => $customername,
            'customer_mobile' => $customermobile,
            'customer_address' => $customeraddress,
            'delivery_area_id' => $deliveryareaid,
            'delivery_time' => $deliveryDate . ' ' . $deliveryTime,
            'reference_invoice' => $referenceinvoice,
            'package_description' => $packagedescription,
            'deliveryman_note' => $deliverynote,
            'order_state_id' => $newOrder_Default->orderstateid,
//            'user_id' => $user_id,
            'updated_at' => $cenvertedCurrentTime,
        );

        $response = $this->db
                ->where('order_id', $order_id)
                ->update('orders', $update_order);



        /*
          //insert for new item charge---------------------------------------------------------
          if (!empty($final_array)) {
          foreach ($final_array as $item) {
          if ($item[0] != '' && $item[1] && $item[2]) {
          $orderItem = array(
          'order_id' => $order_id,
          'item_name' => $item[0],
          'quantity' => $item[1],
          'unit_price' => $item[2],
          'total' => '',
          'created_at' => date('Y-m-d H:i:s'),
          );
          $response3 = $this->db->insert('order_details', $orderItem);
          //                    echo '<pre>';
          //                    print_r($orderItem);
          //                    echo '</pre>';
          }
          }
          }
         * 
         */
        
        
        //update (adjust) product inventory--------------------------------------------------------------------
        
        $prodLogs=$this->db
                ->select('*')
                ->where('order_id',$order_id)
                ->where('status',1)
                ->get('product_logs')
                ->result();
        if(!empty($prodLogs)){
            foreach($prodLogs as $pLogs){
                $pQty = $pLogs->qty;
                $itemCode_get=$pLogs->item_code;
                $itemInfoGet=$this->db->where('item_code',$itemCode_get)->get('product')->row();
                if(!empty($itemInfoGet)){
                    $itemOldQty = $itemInfoGet->qty;
                    $totalItemQty= $pQty + $itemOldQty;
                    //update item qty---------------------------
                    $this->db
                            ->where('item_code',$itemCode_get)
                            ->set('qty',$totalItemQty)
                            ->update('product');
                    $this->db
                            ->where('order_id',$order_id)
                            ->where('item_code',$itemCode_get)
                            ->set('status',0)
                            ->update('product_logs');
                }
            }
        }
        
//        echo $pQty;
//        echo '<pre>';
//        print_r($prodLogs);
//        echo '</pre>';        
//        die();
        
        
        

        //update or insert item info-------------------------------------------------------------------------
        if (!empty($item)) {
            foreach ($item as $item2) {
                if (!isset($item2['order_details_id'])) { // insert new item
                    if (($item2['quantity'] != '' || $item2['quantity'] != 0) && ($item2['price'] != '' || $item2['price'] != 0)) {
                        $item_code = $item2['item_code'];
                        $insertOrderItem = array(
                            'order_id' => $order_id,
                            'item_name' => $item2['itemname'],
                            'item_code' => $item_code,
                            'quantity' => $item2['quantity'],
                            'unit_price' => $item2['price'],
                            'total' => $item2['quantity'] * $item2['price'],
                            'created_at' => $cenvertedCurrentTime,
                        );
                        $response3 = $this->db->insert('order_details', $insertOrderItem);

                        //update product inventory---------------------------------------------------------------
                        if ($item_code != '') {
                            $productInfo = $this->db
                                    ->where('item_code', $item_code)
                                    ->get('product')
                                    ->row();

                            if (!empty($productInfo)) {
                                $itemQtyOld = $productInfo->qty;
                                $remItemQty = $itemQtyOld - $item2['quantity'];

                                //update Product Qty by  item_code to product inventory-----------------------------------------
                                $responseInventory = $this->db
                                        ->where('item_code', $item_code)
                                        ->set('qty', $remItemQty)
                                        ->update('product');

                                //insert to product log----------------------------------------------------------------------
                                $inventoryLog = array(
                                    'product_id' => 0,
                                    'order_id' => $order_id,
                                    'category_id' => 0,
                                    'name' => $item2['itemname'],
                                    'item_code' => $item_code,
                                    'qty' => $item2['quantity'],
                                    'type' => 'New Order Create',
                                    'created_by' => $this->session->userdata('user_id'),
                                    'created_at' => $cenvertedCurrentTime,
                                    'updated_at' => $cenvertedCurrentTime,
                                );
                                $responseInventoryLog = $this->db->insert('product_logs', $inventoryLog);
                            }
                        }

//                    echo '<pre>';
//                    print_r($insertOrderItem);
//                    echo '</pre>';
//                    exit();
                    }
                } elseif (isset($item2['order_details_id'])) {//update item info
                    if (($item2['quantity'] != '' || $item2['quantity'] != 0) && ($item2['price'] != '' || $item2['price'] != 0)) {
                        $item_code = $item2['item_code'];
                        $updateOrderItem = array(
                            'item_name' => $item2['itemname'],
                            'item_code' => $item_code,
                            'quantity' => $item2['quantity'],
                            'unit_price' => $item2['price'],
                            'total' => $item2['quantity'] * $item2['price'],
                            'updated_at' => $cenvertedCurrentTime,
                        );

                        $responseUpdateItem = $this->db
                                ->where('order_details_id', $item2['order_details_id'])
                                ->update('order_details', $updateOrderItem);
                        
                            //update product inventory---------------------------------------------------------------
                            if ($item_code != '') {
                                $productInfo = $this->db
                                        ->where('item_code', $item_code)
                                        ->get('product')
                                        ->row();

                                if (!empty($productInfo)) {
                                    $itemQtyOld_1 = $productInfo->qty;
                                    $remItemQty_ = $itemQtyOld_1 - $item2['quantity'];

                                    //update Product Qty by  item_code to product inventory-----------------------------------------
                                    $responseInventory = $this->db
                                            ->where('item_code', $item_code)
                                            ->set('qty', $remItemQty_)
                                            ->update('product');

                                    //insert to product log----------------------------------------------------------------------
                                    $inventoryLog = array(
                                        'product_id' => 0,
                                        'order_id' => $order_id,
                                        'category_id' => 0,
                                        'name' => $item2['itemname'],
                                        'item_code' => $item_code,
                                        'qty' => $item2['quantity'],
                                        'created_by' => $this->session->userdata('user_id'),
                                        'type' => 'Update Order Info',
                                        'created_at' => $cenvertedCurrentTime,
                                        'updated_at' => $cenvertedCurrentTime,
                                    );
                                    $responseInventoryLog = $this->db->insert('product_logs', $inventoryLog);
                                }
                            }
                    }
                }
            }
        }


        $sess['success'] = 'Updated Successfully!';
        $this->session->set_userdata($sess);
        redirect('admin/order/order_edit/' . $order_id);
    }

    public function order_edit($order_id) {
        $data = array();
        $data['menu'] = '';
        $user_id = $this->session->userdata('user_id');

        $data['orderinfo'] = $this->db
                ->select('*')
                ->where('order_id', $order_id)
                ->get('orders')
                ->row();
        $data['orderItem'] = $this->db
                ->select('*')
                ->where('order_id', $order_id)
                ->get('order_details')
                ->result();

        $data['orderItemTotal'] = count($data['orderItem']);

        $data['orderType'] = $this->db
                ->select('*')
                ->where('order_type_id', $data['orderinfo']->order_type_id)
                ->get('order_type')
                ->row();
        $data['pickupArea'] = $this->db
                ->select('*')
                ->where('areaid', $data['orderinfo']->pickup_area_id)
                ->get('areas')
                ->row();
        $data['deliveryArea'] = $this->db
                ->select('*')
                ->where('areaid', $data['orderinfo']->delivery_area_id)
                ->get('areas')
                ->row();

        /* time convert to am/pm
          $currentDateTime = '08/04/2010 22:15:00';
          $currentDateTime = '22:15:00';
          echo $newDateTime = date('h:i A', strtotime($currentDateTime));
         * 
         */

//        echo '<pre>';
//        print_r($data['orderinfo']);
//        echo '</pre>';
//        exit();

        $data['delivery'] = $this->db
                ->select('*')
                ->get('order_type')
                ->result();
        $data['area'] = $this->db
                ->select('*')
                ->order_by('area_name', 'asc')
                ->get('areas')
                ->result();

        $data['header'] = $this->load->view('dashboard-admin/common/admin-header', $data, TRUE);
        $data['footer'] = $this->load->view('dashboard-admin/common/admin-footer', $data, TRUE);
        $this->load->view('dashboard-admin/order/edit-order', $data);
    }

    public function states() {
        $data = array();
        $data['menu'] = '';

        $data['states'] = $this->db
                ->select('*')
                ->order_by('orderstatename', 'asc')
                ->get('order_state')
                ->result();

        $data['header'] = $this->load->view('dashboard-admin/common/admin-header', $data, TRUE);
        $data['footer'] = $this->load->view('dashboard-admin/common/admin-footer', $data, TRUE);
        $this->load->view('dashboard-admin/order/order-states', $data);
    }

//
    public function order_states_save() {

        $startTime = date("Y-m-d H:i:s");
        $cenvertedCurrentTime = date('Y-m-d H:i:s', strtotime('+6 hour', strtotime($startTime)));

        $data['orderstatename'] = $this->input->post('statename');
        $data['state_color'] = $this->input->post('color');
        $data['created_at'] = $cenvertedCurrentTime;

        $this->db->insert('order_state', $data);

        $sess['success'] = 'Created Successfully!';
        $this->session->set_userdata($sess);
        redirect('admin/order/states');
    }

    public function edit_order_state($id) {
        $data = array();
        $data['menu'] = '';
        $data['result'] = $this->db
                ->select('*')
                ->where('orderstateid', $id)
                ->get('order_state')
                ->row();

        $data['header'] = $this->load->view('dashboard-admin/common/admin-header', $data, TRUE);
        $data['footer'] = $this->load->view('dashboard-admin/common/admin-footer', $data, TRUE);
        $this->load->view('dashboard-admin/order/order-states-edit', $data);
    }

    public function order_states_update() {

        $id = $this->input->post('id');
        $orderstatename = $this->input->post('orderstatename');
        $state_color = $this->input->post('state_color');
        $this->db
                ->where('orderstateid', $id)
                ->set('orderstatename', $orderstatename)
                ->set('state_color', $state_color)
                ->update('order_state');

        $sess['success'] = 'Updated Successfully!';
        $this->session->set_userdata($sess);
        redirect('admin/order/states');
    }

    public function payment_type() {
        $data = array();
        $data['menu'] = '';

        $data['result'] = $this->db
                ->select('*')
                ->order_by('payment_type_name', 'asc')
                ->get('payment_types')
                ->result();

        $data['header'] = $this->load->view('dashboard-admin/common/admin-header', $data, TRUE);
        $data['footer'] = $this->load->view('dashboard-admin/common/admin-footer', $data, TRUE);
        $this->load->view('dashboard-admin/order/payment-type', $data);
    }

    public function payment_type_save() {
        $data['payment_type_name'] = $this->input->post('paymenttypename');
        $this->db->insert('payment_types', $data);

        $sess['success'] = 'Created Successfully!';
        $this->session->set_userdata($sess);
        redirect('admin/order/payment_type');
    }

    public function edit_payment_type($id) {
        $data = array();
        $data['menu'] = '';
        $data['result'] = $this->db
                ->select('*')
                ->where('payment_type_id', $id)
                ->get('payment_types')
                ->row();

        $data['header'] = $this->load->view('dashboard-admin/common/admin-header', $data, TRUE);
        $data['footer'] = $this->load->view('dashboard-admin/common/admin-footer', $data, TRUE);
        $this->load->view('dashboard-admin/order/payment-type-edit', $data);
    }

//
    public function payment_type_update() {

        $id = $this->input->post('id');
        $payment_type_name = $this->input->post('payment_type_name');

        $this->db
                ->where('payment_type_id', $id)
                ->set('payment_type_name', $payment_type_name)
                ->update('payment_types');

        $sess['success'] = 'Updated Successfully!';
        $this->session->set_userdata($sess);
        redirect('admin/order/payment_type');
    }

    public function delete_order($order_id) {
        $data = array();
        $data['orderinfo'] = $this->db
                ->select('*')
                ->where('order_id', $order_id)
                ->get('orders')
                ->row();
//        echo '<pre>';
//        print_r($data['orderinfo']);
//        echo '</pre>';
        if (empty($data['orderinfo'])) {
            echo 'No record found!';
        } else {
            $data['order_id'] = $order_id;
            $data['header'] = $this->load->view('dashboard-admin/common/admin-header', $data, TRUE);
            $data['footer'] = $this->load->view('dashboard-admin/common/admin-footer', $data, TRUE);
            $this->load->view('dashboard-admin/order-status/order-task/delete-order', $data);
        }
    }

    public function delete_order_by_orderid() {
//        echo 'DELETE';
//        echo '<pre>';
//       print_r($_POST);
//        echo '</pre>';
//        exit();

        $response = '';
        $startTime = date("Y-m-d H:i:s");
        $cenvertedCurrentTime = date('Y-m-d H:i:s', strtotime('+6 hour', strtotime($startTime)));

        $order_id = $this->input->post('order_id');
        $remarks = $this->input->post('remarks');
        if ($order_id != '' && $remarks != '') {
            $response = $this->db
                    ->where('order_id', $order_id)
                    ->set('showing_status', 0)
                    ->set('updated_at', $cenvertedCurrentTime)
                    ->set('deleted_at', $cenvertedCurrentTime)
                    ->update('orders');

            if ($response == 1) {
                //update (adjust) product inventory--------------------------------------------------------------------

                $prodLogs = $this->db
                        ->select('*')
                        ->where('order_id', $order_id)
                        ->where('status', 1)
                        ->get('product_logs')
                        ->result();
//        echo '<pre>';
//       print_r($prodLogs);
//        echo '</pre>';
        
                if (!empty($prodLogs)) {
                    foreach ($prodLogs as $pLogs) {
                        $pQty = $pLogs->qty;
                        $itemCode_get = $pLogs->item_code;
                        $itemInfoGet = $this->db->where('item_code', $itemCode_get)->get('product')->row();
                        if (!empty($itemInfoGet)) {
                            $itemOldQty = $itemInfoGet->qty;
                            $totalItemQty = $pQty + $itemOldQty;
                            //update item qty---------------------------
                            $this->db
                                    ->where('item_code', $itemCode_get)
                                    ->set('qty', $totalItemQty)
                                    ->update('product');
                            $this->db
                                    ->where('order_id', $order_id)
                                    ->where('item_code', $itemCode_get)
                                    ->set('status', 0)
                                    ->set('updated_at', $cenvertedCurrentTime)
                                    ->update('product_logs');
                        }
                    }
                }

                echo 'Deleted Successfully!';
            } else {
                echo 'false';
            }
        }
    }

    public function report() {
        $data = array();
        $data['menu'] = '';

        $data['header'] = $this->load->view('dashboard-admin/common/admin-header', $data, TRUE);
        $data['footer'] = $this->load->view('dashboard-admin/common/admin-footer', $data, TRUE);
        $this->load->view('dashboard-admin/order/order-report', $data);
    }

    public function pickup($order_id) {
        $data = array();
        $data['orderinfo'] = $this->db
                ->select('*')
                ->where('order_id', $order_id)
                ->get('orders')
                ->row();
//        echo '<pre>';
//        print_r($data['orderinfo']);
//        echo '</pre>';
        if (empty($data['orderinfo'])) {
            echo 'No record found!';
        } else {
            $data['order_id'] = $order_id;
            $data['header'] = $this->load->view('dashboard-admin/common/admin-header', $data, TRUE);
            $data['footer'] = $this->load->view('dashboard-admin/common/admin-footer', $data, TRUE);
            $this->load->view('dashboard-admin/order-status/order-task/pickup-task', $data);
        }
    }

    public function pickup_task() {
//        echo '<pre>';
//        print_r($_POST);
//        echo '</pre>';
//        exit();
//        echo 'Pickup Task';
//        exit();

        /*
         * $orderstate = DB::select("SELECT orderstateid FROM order_state WHERE orderstatename='Completed'");
          $task_type = DB::select("SELECT task_type_id FROM task_types WHERE type_name='Pickup'");

          // Saving task
          $task = new OrderTask;
          $task->order_id = $request->input('orderid');
          $task->remarks = $request->input('remarks');
          $task->task_state_id = $orderstate[0]->orderstateid;
          $task->task_type_id =  $task_type[0]->task_type_id;
          $task->user_id = $request->input('userid');
          $task->save();

          // Updating order
          $order = Order::find($request->input('orderid'));
          $order->ispickup_completed =  1;
          $order->save();
         */

        $data = array();
        $response = '';

        $startTime = date("Y-m-d H:i:s");
        $cenvertedCurrentTime = date('Y-m-d H:i:s', strtotime('+6 hour', strtotime($startTime)));

        $data['order_id'] = $order_id = $this->input->post('order_id');
        $data['remarks'] = $remarks = $this->input->post('remarks');
        $task_type = $this->db
                ->select('*')
                ->where('type_name', 'Pickup') // task type for pickup
                ->get('task_types')
                ->row();
        $order_state = $this->db
                ->select('*')
                ->where('orderstatename', 'Started') //for order status name
                ->get('order_state')
                ->row();
        $data['task_state_id'] = $task_state_id = $order_state->orderstateid;
        $data['task_type_id'] = $task_type->task_type_id;
        $data['user_id'] = $this->session->userdata('user_id');
        $data['created_at'] = $cenvertedCurrentTime;

        if ($task_state_id != '' && $remarks != '') {
            $response = $this->db->insert('order_tasks', $data);
        }

        if ($response == 1) {
            $this->db
                    ->where('order_id', $order_id)
                    ->set('ispickup_completed', 1)
                    ->set('order_state_id', $task_state_id)
                    ->set('updated_at', $cenvertedCurrentTime)
                    ->update('orders');
            echo 'Success!';
        } else {
            echo 'Failed! Try again.';
        }
    }

    public function delivery($order_id) {
        $data = array();
        $data['orderinfo'] = $this->db
                ->select('*')
                ->where('order_id', $order_id)
                ->get('orders')
                ->row();
//        echo '<pre>';
//        print_r($data['orderinfo']);
//        echo '</pre>';
        if (empty($data['orderinfo'])) {
            echo 'No record found!';
        } else {
            $data['states'] = $this->db
                    ->select('*')
                    ->order_by('orderstatename', 'asc')
                    ->get('order_state')
                    ->result();
            $data['order_id'] = $order_id;
            $data['header'] = $this->load->view('dashboard-admin/common/admin-header', $data, TRUE);
            $data['footer'] = $this->load->view('dashboard-admin/common/admin-footer', $data, TRUE);
            $this->load->view('dashboard-admin/order-status/order-task/delivery-task', $data);
        }
    }

    public function delivery_task() {
//        echo '<pre>';
//        print_r($_POST);
//        echo '</pre>';
//        echo 'Delivery Task';
//        exit();


        $data = array();
        $response = '';
        $data['task_state_id'] = $task_state_id = $this->input->post('orderstateid'); // order status name (complete/pending/etc)
        $data['order_id'] = $order_id = $this->input->post('order_id');
        $data['remarks'] = $remarks = $this->input->post('remarks');
        $task_type = $this->db
                ->select('*')
                ->where('type_name', 'Delivery') //for delivery
                ->get('task_types')
                ->row();

        $startTime = date("Y-m-d H:i:s");
        $cenvertedCurrentTime = date('Y-m-d H:i:s', strtotime('+6 hour', strtotime($startTime)));

        $data['task_type_id'] = $task_type->task_type_id;
        $data['user_id'] = $this->session->userdata('user_id');
        $data['created_at'] = $cenvertedCurrentTime;

        if ($task_state_id != '' && $remarks != '') {
            $response = $this->db->insert('order_tasks', $data);
        }
        if ($response == 1) {
            //update order status to Orders table----------------------------------
            $this->db
                    ->where('order_id', $order_id)
                    ->set('order_state_id', $task_state_id)
                    ->set('updated_at', $cenvertedCurrentTime)
                    ->update('orders');

            echo 'Success!';
        } else {
            echo 'Failed! Try again.';
        }

//       echo '<pre>';
//        print_r($task_type);
//        echo '</pre>';
    }

    public function task_assign($order_id) {
        $data = array();
        $data['orderinfo'] = $this->db
                ->select('*')
                ->where('order_id', $order_id)
                ->get('orders')
                ->row();
//        echo '<pre>';
//        print_r($data['orderinfo']);
//        echo '</pre>';
        if (empty($data['orderinfo'])) {
            echo 'No record found!';
        } else {
            $data['states'] = $this->db
                    ->select('*')
                    ->order_by('orderstatename', 'asc')
                    ->get('order_state')
                    ->result();

            $data['delivery_man'] = $this->db
                    ->select('*')
//                ->where('isactive', 1) // active delivery man
                    ->where('user_type_id', 2)// delivery man
                    ->get('users')
                    ->result();

            $data['pickupMan'] = $this->db
                    ->select('*')
                    ->where('order_id', $order_id)
                    ->where('task_type_id', 1)//Pickup
                    ->get('order_task_person')
                    ->result();

            $data['deliveryMan'] = $this->db
                    ->select('*')
                    ->where('order_id', $order_id)
                    ->where('task_type_id', 2)//delivery
                    ->get('order_task_person')
                    ->result();


            $data['order_id'] = $order_id;
            $data['header'] = $this->load->view('dashboard-admin/common/admin-header', $data, TRUE);
            $data['footer'] = $this->load->view('dashboard-admin/common/admin-footer', $data, TRUE);
            $this->load->view('dashboard-admin/order-status/order-task/assign-person', $data);
        }
    }

    public function task_assign_pickup() {
        $data = array();
        $data2 = array();
        $response = '';

        $startTime = date("Y-m-d H:i:s");
        $cenvertedCurrentTime = date('Y-m-d H:i:s', strtotime('+6 hour', strtotime($startTime)));

        $task_type = $this->db
                ->select('*')
                ->where('type_name', 'Pickup') //for pickup
                ->get('task_types')
                ->row();

        $data['order_id'] = $order_id = $this->input->post('order_id');
        $data['task_type_id'] = $task_type_id = $task_type->task_type_id;
        $data['remarks'] = $remarks = $this->input->post('remarks');
        $data['user_id'] = $this->input->post('userid');
        $data['created_at'] = $cenvertedCurrentTime;

        if ($task_type_id != '' && $remarks != '') {
            $response = $this->db->insert('order_task_person', $data);
        }


//        echo '<pre>';
//        print_r($data);
//        print_r($_POST);
//        echo '</pre>';

        if ($response == 1) {
            $order_state = $this->db
                    ->select('*')
                    ->where('orderstatename', 'Started') //for order status name
                    ->get('order_state')
                    ->row();

            $response2 = $this->db
                    ->where('order_id', $order_id)
                    ->set('order_state_id', $order_state->orderstateid)
                    ->set('updated_at', $cenvertedCurrentTime)
                    ->update('orders');
        }

//        echo $response;
//        echo '<br>';
//        echo $response2;
//        echo '<br>';

        if ($response == 1) {
//            echo 'success';
            $data2['pickupMan'] = $this->db
                    ->select('*')
                    ->where('order_id', $order_id)
                    ->where('task_type_id', 1)//Pickup
                    ->get('order_task_person')
                    ->result();
            $this->load->view('dashboard-admin/order-status/assign/assign-pickup-man', $data2);
        } else {
            echo 'Failed! Try again.';
        }
    }

    public function task_assign_delivery() {

//        echo 'Hello delivery';
//        exit();

        $data = array();
        $data2 = array();
        $response = '';
        $startTime = date("Y-m-d H:i:s");
        $cenvertedCurrentTime = date('Y-m-d H:i:s', strtotime('+6 hour', strtotime($startTime)));

        $task_type = $this->db
                ->select('*')
                ->where('type_name', 'Delivery') //for delivery
                ->get('task_types')
                ->row();

        $data['order_id'] = $order_id = $this->input->post('order_id');
        $data['task_type_id'] = $task_type_id = $task_type->task_type_id;
        $data['remarks'] = $remarks = $this->input->post('remarks');
        $data['user_id'] = $this->input->post('userid');
        $data['created_at'] = $cenvertedCurrentTime;

        if ($task_type_id != '' && $remarks != '') {
            $response = $this->db->insert('order_task_person', $data);
        }

//        echo '<pre>';
//        print_r($data);
//        print_r($_POST);
//        echo '</pre>';

        if ($response == 1) {
            $order_state = $this->db
                    ->select('*')
                    ->where('orderstatename', 'Started') //for order status name
                    ->get('order_state')
                    ->row();

            $response2 = $this->db
                    ->where('order_id', $order_id)
                    ->set('order_state_id', $order_state->orderstateid)
                    ->set('updated_at', $cenvertedCurrentTime)
                    ->update('orders');
        }

        if ($response == 1) {
//            echo 'success';
            $data2['deliveryMan'] = $this->db
                    ->select('*')
                    ->where('order_id', $order_id)
                    ->where('task_type_id', 2)//delivery
                    ->get('order_task_person')
                    ->result();
            $this->load->view('dashboard-admin/order-status/assign/assign-delivery-man', $data2);
        } else {
            echo 'Failed! Try again.';
        }
    }

    public function assign_selected_order() {

//        echo '<pre>';
//        print_r($_POST);
//        echo '</pre>';
//        exit();
        $order_id = array();
        $data = array();
        $data2 = array();
        $inputArray = array();

        $startTime = date("Y-m-d H:i:s");
        $cenvertedCurrentTime = date('Y-m-d H:i:s', strtotime('+6 hour', strtotime($startTime)));

        $order_id = $this->input->post('order_id'); //array
        $data['user_id'] = $userid = $this->input->post('userid');
        $type = $this->input->post('type'); //pickup/delivery
        $data['remarks'] = $remarks = $this->input->post('remarks');
        $data['created_at'] = $created_at = $cenvertedCurrentTime;


        $order_state = $this->db
                ->select('*')
                ->where('orderstatename', 'Started') //for order status name
                ->get('order_state')
                ->row();

        if ($type == 'Pickup') {
            $task_type = $this->db
                    ->select('*')
                    ->where('type_name', 'Pickup') //for pickup
                    ->get('task_types')
                    ->row();
        } elseif ($type == 'Delivery') {
            $task_type = $this->db
                    ->select('*')
                    ->where('type_name', 'Delivery') //for delivery
                    ->get('task_types')
                    ->row();
        }
        $data['task_type_id'] = $task_type_id = $task_type->task_type_id;

        if (!empty($order_id)) {

            foreach ($order_id as $oRow) {
                $inputArray = array(
                    'order_id' => $oRow,
                    'user_id' => $userid,
                    'task_type_id' => $task_type_id,
                    'remarks' => $remarks,
                    'created_at' => $created_at,
                );


                $response = $this->db->insert('order_task_person', $inputArray);

                if ($response == 1) {
                    $response2 = $this->db
                            ->where('order_id', $oRow)
                            ->set('order_state_id', $order_state->orderstateid)
                            ->set('updated_at', $cenvertedCurrentTime)
                            ->update('orders');
                }
            }
            $sess['success'] = 'Success!';
            $this->session->set_userdata($sess);
            redirect('admin/dashboard/new_order');
        } else {
            $sess['exception'] = 'Please select atleast one order';
            $this->session->set_userdata($sess);
            redirect('admin/dashboard/new_order');
        }
    }

    public function assign_selected_pending_order() {

        $data = array();
        $order_array = $this->input->post('order_id'); //array
        $order_state_id = $this->input->post('orderstateid'); // order status name (complete/pending/etc)
        $remarks = $this->input->post('remarks');
        $order_stateInfo = $this->db
                ->select('*')
                ->where('orderstateid', $order_state_id)
                ->get('order_state')
                ->row();

        $order_stateName = $order_stateInfo->orderstatename;
        $user_id = $this->session->userdata('user_id');
        $task_type_id = 0; // none of delivery/pickup


        $startTime = date("Y-m-d H:i:s");
        $cenvertedCurrentTime = date('Y-m-d H:i:s', strtotime('+6 hour', strtotime($startTime)));

        if (!empty($order_array)) {
            foreach ($order_array as $row) {
                $inputArray = array(
                    'order_id' => $row,
                    'remarks' => $remarks,
                    'task_state_id' => $order_state_id,
                    'task_type_id' => $task_type_id,
                    'user_id' => $user_id,
                    'created_at' => $cenvertedCurrentTime,
                    'updated_at' => $cenvertedCurrentTime,
                );
                $response = $this->db->insert('order_tasks', $inputArray);
                if ($response == 1) {
                    //update order status to Orders table----------------------------------
                    $this->db
                            ->where('order_id', $row)
                            ->set('order_state_id', $order_state_id)
                            ->set('updated_at', $cenvertedCurrentTime)
                            ->update('orders');
                }
            }

            $sess['success'] = 'Success!';
            $this->session->set_userdata($sess);
            redirect('admin/dashboard');
        } else {
            $sess['exception'] = 'Please select at least one order';
            $this->session->set_userdata($sess);
            redirect('admin/dashboard');
        }

//        echo '<pre>';
//        print_r($order_stateInfo);
//        print_r($_POST);
//        echo '</pre>';
//        exit();
    }

}
