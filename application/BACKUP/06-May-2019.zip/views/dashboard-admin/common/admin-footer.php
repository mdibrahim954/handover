<!--<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/inline.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/polyfills.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/vendor.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/main.js"></script>-->
    </body>
</html>