<?php
$response_log = $this->db
    ->select('serial')
    ->where('item_code', $result->item_code)
    ->order_by('serial', 'ASC')
    ->get('inventory_log')
    ->result();

if (isset($header)) {
    echo $header;
}
?>

<style>
    .product-print-card {
        box-sizing: border-box;
        max-width: 560px;
        min-height: 360px;
        margin: 40px auto;
        padding: 36px;
        border: 1px solid #d9e0e8;
        border-radius: 12px;
        background: #fff;
        color: #1f2937;
        font-family: Arial, sans-serif;
        text-align: center;
        box-shadow: 0 8px 24px rgba(31, 41, 55, .08);
    }

    .product-print-eyebrow {
        margin: 0 0 12px;
        color: #64748b;
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 2px;
        text-transform: uppercase;
    }

    .product-print-card h2 {
        margin: 0 0 8px;
        color: #111827;
        font-size: 28px;
        font-weight: 700;
    }

    .product-print-category {
        margin: 0 0 28px;
        color: #64748b;
        font-size: 15px;
    }

    .product-print-barcode {
        display: block;
        width: 100%;
        max-width: 440px;
        height: auto;
        margin: 0 auto 5px;
    }

    .product-print-qrcode {
        display: block;
        width: 180px;
        height: 180px;
        margin: 0 auto 5px;
    }

    .product-print-details {
        display: flex;
        justify-content: center;
        gap: 48px;
        padding-top: 20px;
        border-top: 1px solid #e5e7eb;
    }

    .product-print-detail-label {
        display: block;
        margin-bottom: 6px;
        color: #64748b;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 1px;
        text-transform: uppercase;
    }

    .product-print-detail-value {
        color: #111827;
        font-size: 16px;
        font-weight: 700;
    }

    .product-print-actions {
        margin-bottom: 20px;
    }

    @page {
        size: A4 portrait;
        margin: 15mm;
    }

    @media print {
        html,
        body {
            margin: 0 !important;
            padding: 0 !important;
            background: #fff !important;
        }

        .main-navigation,
        .sidebar,
        .product-print-actions,
        #divProgressLine {
            display: none !important;
        }

        main {
            width: 100% !important;
            max-width: none !important;
            margin: 0 !important;
            padding: 0 !important;
        }

        .product-print-card {
            display: flex;
            width: 100%;
            max-width: none;
            min-height: calc(297mm - 30mm);
            flex-direction: column;
            justify-content: center;
            margin: 0;
            padding: 20mm;
            border: 2px solid #d9e0e8;
            border-radius: 0;
            box-shadow: none;
            page-break-after: always;
            break-after: page;
            page-break-inside: avoid;
            break-inside: avoid;
        }

        .product-print-card:last-of-type {
            page-break-after: auto;
            break-after: auto;
        }

        .product-print-barcode {
            max-width: 160mm;
            max-height: 55mm;
        }

        .product-print-card,
        .product-print-card * {
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }
    }
</style>

<main class="col-sm-8 col-md-8 col-lg-10 col-sm-offset-4 col-md-offset-2 col-lg-offset-2">
    <div class="product-print-actions text-center">
        <button class="btn btn-primary" type="button" onclick="printProductBarcodes()">Print</button>
        <a class="btn btn-default" href="<?php echo base_url(); ?>admin/product/all">Back to products</a>
    </div>
    <?php if (empty($response_log)) { ?>
        <p class="text-center">No serial-number records are available for this product.</p>
    <?php } else {
        foreach ($response_log as $key => $item) { ?>
        <section class="product-print-card mb-3">
            <p class="product-print-eyebrow">Product identification</p>
            <h2><?php echo html_escape($result->name); ?></h2>
            <?php if (!empty($category)) { ?>
                <p class="product-print-category"><?php echo html_escape($category->name); ?></p>
            <?php } else { ?>
                <p class="product-print-category">Inventory item</p>
            <?php } ?>
            <svg class="product-print-barcode" id="product-item-code-<?php echo $key; ?>"></svg>
            <p class="product-serial-codes"><?php echo html_escape((string) $result->item_code) . '-' . html_escape((string) $item->serial); ?></p>
            <div class="product-print-details">
                <div>
                    <span class="product-print-detail-label">Item code</span>
                    <span class="product-print-detail-value"><?php echo html_escape((string) $result->item_code); ?></span>
                </div>
                <div>
                    <span class="product-print-detail-label">Serial number</span>
                    <span class="product-print-detail-value"><?php echo html_escape((string) $item->serial); ?></span>
                </div>
            </div>
            <br>
            <hr>
            <br>
            <p class="product-print-eyebrow">Product identification - For everyone</p>
           
            <div class="product-print-qrcode" id="product-item-code-ev-<?php echo $key; ?>"></div>
            <p class="product-serial-codes"><?php echo html_escape((string) $result->item_code) . '-' . html_escape((string) $item->serial); ?></p>
            

        </section>
    <?php }
    } ?>
</main>

<script src="<?php echo base_url(); ?>assets/js/jquery.qrcode.min.js"></script>
<script>
    const inventoryLog = <?php echo json_encode($response_log, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
    const itemPageUrl = <?php echo json_encode(rtrim(base_url(), '/') . '/item/', JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
    const productBarcodeItemCode = <?php echo json_encode((string) $result->item_code, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;

    window.addEventListener('load', function () {
        inventoryLog.forEach(function (item, i) {
            JsBarcode(`#product-item-code-${i}`, productBarcodeItemCode + '-' + item.serial, {
                format: 'CODE128',
                displayValue: false,
                width: 2,
                height: 80,
                margin: 12
            });

            const itemUrl = itemPageUrl + '?item=' + encodeURIComponent(productBarcodeItemCode) + '&serial=' + encodeURIComponent(String(item.serial));
            new QRCode(document.getElementById(`product-item-code-ev-${i}`), {
                text: itemUrl,
                width: 180,
                height: 180,
                correctLevel: QRCode.CorrectLevel.M
            });
        });
    });

    function printProductBarcodes() {
        if (inventoryLog.length < 1) {
            window.alert('There are no product barcodes to print.');
            return;
        }

        const printWindow = window.open('', '_blank', 'width=900,height=700');
        if (!printWindow) {
            window.alert('Allow pop-ups to print the product barcodes.');
            return;
        }

        const printDocument = printWindow.document;
        printDocument.title = 'Product barcodes';

        const style = printDocument.createElement('style');
        style.textContent = `
            @page { size: A4 portrait; margin: 15mm; }
            * { box-sizing: border-box; }
            body {
                margin: 0;
                color: #1f2937;
                font-family: Arial, sans-serif;
            }
            .product-print-card {
                display: flex;
                width: 100%;
                min-height: calc(297mm - 30mm);
                flex-direction: column;
                justify-content: center;
                margin: 0;
                padding: 20mm;
                border: 2px solid #d9e0e8;
                text-align: center;
                page-break-after: always;
                break-after: page;
                page-break-inside: avoid;
                break-inside: avoid;
            }
            .product-print-card:last-child {
                page-break-after: auto;
                break-after: auto;
            }
            .product-print-eyebrow {
                margin: 0 0 12px;
                color: #64748b;
                font-size: 12px;
                font-weight: 700;
                letter-spacing: 2px;
                text-transform: uppercase;
            }
            .product-print-card h2 {
                margin: 0 0 8px;
                color: #111827;
                font-size: 28px;
            }
            .product-print-category {
                margin: 0 0 28px;
                color: #64748b;
                font-size: 15px;
            }
            .product-print-barcode {
                display: block;
                width: 100%;
                max-width: 160mm;
                max-height: 55mm;
                margin: 0 auto 5px;
            }
            .product-print-qrcode {
                display: block;
                width: 180px;
                height: 180px;
                margin: 0 auto 5px;
            }
            .product-print-details {
                display: flex;
                justify-content: center;
                gap: 48px;
                padding-top: 20px;
                border-top: 1px solid #e5e7eb;
            }
            .product-print-detail-label {
                display: block;
                margin-bottom: 6px;
                color: #64748b;
                font-size: 11px;
                font-weight: 700;
                letter-spacing: 1px;
                text-transform: uppercase;
            }
            .product-print-detail-value {
                color: #111827;
                font-size: 16px;
                font-weight: 700;
            }
            @media print {
                .product-print-card,
                .product-print-card * {
                    -webkit-print-color-adjust: exact;
                    print-color-adjust: exact;
                }
            }
        `;
        printDocument.head.appendChild(style);

        document.querySelectorAll('.product-print-card').forEach(function (card) {
            const printCard = card.cloneNode(true);
            card.querySelectorAll('canvas').forEach(function (canvas) {
                const clonedCanvas = printCard.querySelector('#' + canvas.parentElement.id + ' canvas');
                if (clonedCanvas) {
                    const qrImage = printDocument.createElement('img');
                    qrImage.src = canvas.toDataURL('image/png');
                    qrImage.width = canvas.width;
                    qrImage.height = canvas.height;
                    qrImage.alt = 'QR code';
                    clonedCanvas.parentNode.replaceChild(qrImage, clonedCanvas);
                }
            });
            printDocument.body.appendChild(printCard);
        });

        printWindow.addEventListener('afterprint', function () {
            printWindow.close();
        });
        printWindow.focus();
        printWindow.print();
    }
</script>

</ng-component></app-root></div></div>
<?php
if (isset($footer)) {
    echo $footer;
}
?>