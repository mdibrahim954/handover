<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('user_id') && $this->session->userdata('user_type_id') != 1) {
            redirect(base_url());
        }
        $this->load->model('user_dashboard_model');
    }

    public function index() {
//        $this->load->library('form_validation');
//        $data = array();
//        $data['menu'] = 'inventory';
//        $user_id = $this->session->userdata('user_id');
//
//        $data['testimonial'] = $this->db
//                ->select('*')
//                ->get('product')
//                ->result();
//
//        $data['header'] = $this->load->view('dashboard-admin/common/admin-header', $data, TRUE);
//        $data['footer'] = $this->load->view('dashboard-admin/common/admin-footer', $data, TRUE);
//        $this->load->view('dashboard-admin/inventory/price-view', $data);
    }
    
    public function search_product() {
        
        $data = array();
        $data['menu'] = 'inventory';

        $category_id = trim($this->input->post('category_id'));
        $search_text = trim($this->input->post('search_text'));
        
        $data['result'] = $this->user_dashboard_model->searchProduct($search_text, $category_id);
        
        $data['header'] = $this->load->view('dashboard-admin/common/admin-header', $data, TRUE);
        $data['footer'] = $this->load->view('dashboard-admin/common/admin-footer', $data, TRUE);
        $this->load->view('dashboard-admin/inventory/product/search-product-view', $data);
    }

    public function all($id = null) {

        if ($this->uri->segment(5)) {

            $offset = $this->uri->segment(5);
        } else {

            $offset = 0;
        }

        $this->load->library('form_validation');
        $data = array();
        $data['menu'] = 'inventory';
        $user_id = $this->session->userdata('user_id');

        $data['all_product'] = $this->db
                ->select('*')
//                ->join('product_category','product_category.id=product.category_id')
                ->get('product')
                ->result();

        //        ------------------------Pagination Start----------------------------------------------
        $abc = count($data['all_product']);

        //        Pagination Start
        $this->load->library('pagination');

        $config['base_url'] = base_url() . 'admin/product/all/' . $id;
        $config['total_rows'] = $abc;
        $config['per_page'] = 20;
        $config['uri_segment'] = 5;
        $config['num_links'] = 4;

        //pagination settings
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = 'Previous';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = 'Next';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';

        $this->pagination->initialize($config);
//        Pagination End
        $data['result'] = $this->user_dashboard_model->selectAllProductPagination($config['per_page'], $offset);

//        echo '<pre>';
//        print_r($data['result']);
//        echo '</pre>';
//        die();

        $data['header'] = $this->load->view('dashboard-admin/common/admin-header', $data, TRUE);
        $data['footer'] = $this->load->view('dashboard-admin/common/admin-footer', $data, TRUE);
        $this->load->view('dashboard-admin/inventory/product/all-view', $data);
    }

    public function create() {
        $this->load->library('form_validation');
        $data = array();
        $data['menu'] = 'inventory';
        $user_id = $this->session->userdata('user_id');

        $data['category'] = $this->db
                ->select('*')
                ->where('status', 1)
                ->get('product_category')
                ->result();

//        echo '<pre>';
//        print_r($category);
//        echo '</pre>';

        $data['header'] = $this->load->view('dashboard-admin/common/admin-header', $data, TRUE);
        $data['footer'] = $this->load->view('dashboard-admin/common/admin-footer', $data, TRUE);
        $this->load->view('dashboard-admin/inventory/product/create-view', $data);
    }

    public function save() {
        $data = array();
        $data['name'] = $name = trim($this->input->post('name'));
        $data['category_id'] = trim($this->input->post('category_id'));
        $data['item_code'] = $item_code = trim($this->input->post('item_code'));
        $data['qty'] = trim($this->input->post('qty'));
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');

        $duplicateCheck = $this->db
                ->select('*')
//                ->where('name', $name)
//                ->or_where('item_code', $item_code)
                ->where('item_code', $item_code)
                ->get('product')
                ->row();

        if (empty($duplicateCheck)) {

            $response = $this->db->insert('product', $data);
            $insert_id = $this->db->insert_id();

            if ($response == 1) {
                $data['product_id'] = $insert_id;
                $data['type'] = 'Insert';
                $data['created_by'] = $this->session->userdata('user_id');
                $response2 = $this->db->insert('product_logs', $data);

                $sess['success'] = 'Success!';
                $this->session->set_userdata($sess);
                redirect('admin/product/all');
            } else {
                $sess['exception'] = 'Something went to wrong! Try again';
                $this->session->set_userdata($sess);
                redirect('admin/product/create');
            }
        } else {
            $sess['exception'] = 'Oh! Already exist this Item Code. You can\'t create duplicate Item Code.';
            $this->session->set_userdata($sess);
            redirect('admin/product/create');
        }
    }

    public function edit($id) {
        $data = array();
        $data['menu'] = 'inventory';
        $data['result'] = $this->db
                ->select('*')
                ->where('id', $id)
                ->get('product')
                ->row();
        $data['category'] = $this->db
                ->select('*')
                ->where('status', 1)
                ->get('product_category')
                ->result();

        $data['header'] = $this->load->view('dashboard-admin/common/admin-header', $data, TRUE);
        $data['footer'] = $this->load->view('dashboard-admin/common/admin-footer', $data, TRUE);
        $this->load->view('dashboard-admin/inventory/product/edit-view', $data);
    }

    public function update() {
        $data = array();
        $id = $this->input->post('id');
        $data['name'] = $name = trim($this->input->post('name'));
        $data['category_id'] = trim($this->input->post('category_id'));
        $data['item_code'] = $item_code = trim($this->input->post('item_code'));
        $data['qty'] = trim($this->input->post('qty'));
        $data['updated_at'] = date('Y-m-d H:i:s');

        $response = $this->db
                ->where('id', $id)
                ->update('product', $data);

        if ($response == 1) {
            $data['product_id'] = $id;
            $data['type'] = 'Update';
            $data['created_by'] = $this->session->userdata('user_id');
            $data['created_at'] = date('Y-m-d H:i:s');
            $response2 = $this->db->insert('product_logs', $data);

            $sess['success'] = 'Success!';
            $this->session->set_userdata($sess);
            redirect('admin/product/all');
        } else {
            $sess['exception'] = 'Something went to wrong! Try again';
            $this->session->set_userdata($sess);
            redirect('admin/product/all');
        }
    }

    public function delete($id) {
        $response = $this->db
                ->where('id', $id)
                ->set('status', 0)
                ->update('product');

        if ($response == 1) {
            $sess['success'] = 'Success!';
            $this->session->set_userdata($sess);
            redirect('admin/product/all');
        } else {
            $sess['exception'] = 'Something went to wrong! Try again';
            $this->session->set_userdata($sess);
            redirect('admin/product/all');
        }
    }

}
